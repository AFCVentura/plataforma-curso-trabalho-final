document.addEventListener('DOMContentLoaded', () => {
    // Selecionar o contêiner de vídeo principal e as abas do sidebar
    const videoContainer = document.querySelector('.video-container iframe');
    const sidebarItems = document.querySelectorAll('.sidebar-item');

    // Selecionar os elementos do modal
    const liveButton = document.getElementById('liveButton');
    const liveModal = document.getElementById('liveModal');
    const startLiveButton = document.getElementById('startLiveButton');
    const cancelLiveButton = document.getElementById('cancelLiveButton');

    // Adicionar ouvintes de eventos aos itens do sidebar
    sidebarItems.forEach(item => {
        item.addEventListener('click', () => {
            const videoId = item.getAttribute('data-video-id');
            videoContainer.src = `https://www.youtube.com/embed/${videoId}`;
        });

        // Adicionar vídeos do YouTube aos contêineres de vídeo do sidebar
        const videoId = item.getAttribute('data-video-id');
        const sidebarVideoContainer = item.querySelector('.sidebar-video-container');
        const iframe = document.createElement('iframe');
        iframe.src = `https://www.youtube.com/embed/${videoId}`;
        iframe.frameBorder = 0;
        iframe.allow = 'accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture';
        iframe.allowFullscreen = true;
        sidebarVideoContainer.appendChild(iframe);
    });

    // Mostrar o modal ao clicar no botão "Live"
    liveButton.addEventListener('click', () => {
        liveModal.style.display = 'block';
    });

    // Ocultar o modal ao clicar no botão "Cancelar"
    cancelLiveButton.addEventListener('click', () => {
        liveModal.style.display = 'none';
    });

    // Iniciar a live ao clicar no botão "Iniciar" (aqui você pode adicionar mais funcionalidades)
    startLiveButton.addEventListener('click', () => {
        const liveTitle = document.getElementById('liveTitle').value;
        const liveURL = document.getElementById('liveURL').value;
        const liveDescription = document.getElementById('liveDescription').value;

        // Validação básica
        if (!liveTitle || !liveURL) {
            alert('Por favor, preencha o título e a URL da live.');
            return;
        }

        // Aqui você pode adicionar código para iniciar a live, salvar os dados, etc.
        alert(`Iniciando live: ${liveTitle}\nURL: ${liveURL}\nDescrição: ${liveDescription}`);

        // Fechar o modal
        liveModal.style.display = 'none';
    });

    // Fechar o modal se o usuário clicar fora do conteúdo do modal
    window.addEventListener('click', (event) => {
        if (event.target == liveModal) {
            liveModal.style.display = 'none';
        }
    });
});
