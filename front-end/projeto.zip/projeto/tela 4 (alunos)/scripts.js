document.querySelectorAll('.curso').forEach(curso => {
    curso.addEventListener('click', () => {
        const courseId = curso.getAttribute('data-course');
        window.location.href = `aula.html`;
    });
});

function redirectToAula() {
    window.location.href = "../tela 5/aula.html";
}

document.addEventListener('DOMContentLoaded', (event) => {
    document.querySelectorAll('.curso').forEach(element => {
        element.addEventListener('click', redirectToAula);
    });
});