document.querySelectorAll('.curso').forEach(curso => {
    curso.addEventListener('click', () => {
        const courseId = curso.getAttribute('data-course');
        window.location.href = `tela_prof.html`;
    });
});

document.addEventListener("DOMContentLoaded", function() {
    // Abrir e fechar o modal
    var modal = document.getElementById("course-modal");
    var addItemButton = document.getElementById("add-item-button");
    var closeButton = document.querySelector(".close-button");
    var cancelCourseButton = document.getElementById("cancel-course-button");
    var startCourseButton = document.getElementById("start-course-button");
    var courseNameInput = document.getElementById("course-name-input");

    addItemButton.onclick = function() {
        modal.style.display = "flex";
    };

    closeButton.onclick = function() {
        modal.style.display = "none";
    };

    cancelCourseButton.onclick = function() {
        modal.style.display = "none";
    };

    startCourseButton.onclick = function() {
        var courseName = courseNameInput.value.trim();
        if (courseName) {
            alert("Curso " + courseName + " criado com sucesso!");
            modal.style.display = "none";
            // Aqui você pode adicionar o código para salvar o curso na lista de cursos
        } else {
            alert("Por favor, insira o nome do curso.");
        }
    };

    // Fechar o modal clicando fora dele
    window.onclick = function(event) {
        if (event.target == modal) {
            modal.style.display = "none";
        }
    };
});
