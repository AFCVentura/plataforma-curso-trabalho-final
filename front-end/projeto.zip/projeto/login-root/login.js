document.addEventListener("DOMContentLoaded", function() {
    // vai redirecionar para a pagina de registro
    document.getElementById("register-button").addEventListener("click", function() {
        window.location.href = "registro.html";
    });

    // validar o formulario 
    document.getElementById("register-submit").addEventListener("click", function(event) {
        event.preventDefault();
        
        let email = document.getElementById("email").value;
        let name = document.getElementById("name").value;
        let password = document.getElementById("password").value;

        if (!name || !email || !password) {
            alert("Por favor, preencha todos os campos obrigatórios.");
            return;
        }

        if (email.endsWith("@alunos.com.br")) {
            alert("Bem-vindo, aluno!");
        } else if (email.endsWith("@professor.com.br")) {
            alert("Bem-vindo, professor!");
        } else {
            alert("Email não reconhecido. Por favor, utilize um email válido.");
            return;
        }

        
        window.location.href = "login.html";
    });

    // Validação do formulário de login
    document.getElementById("login-form").addEventListener("submit", function(event) {
        event.preventDefault();
        
        let email = document.getElementById("email").value;
        let password = document.getElementById("password").value;

        if (!email || !password) {
            alert("Por favor, preencha todos os campos.");
            return;
        }

        function redirectToAlunos() {
            window.location.href = "../tela 4 (alunos)/index.html";
        }
    });
});

